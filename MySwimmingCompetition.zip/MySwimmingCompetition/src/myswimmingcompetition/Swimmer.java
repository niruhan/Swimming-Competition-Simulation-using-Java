package myswimmingcompetition;

import java.util.Random;

public class Swimmer { 
    //int speed =4;
    int distance;
    int maxSpeed;
    String name;
    Thread t;
    
    public void startSwimming(final int maxSpeedLocal) {
        t = new Thread() {
            @Override
            public void run() {
                while(true) {
                    Random randomSpeed = new Random();
                    distance += randomSpeed.nextInt(maxSpeedLocal);
                    try {
                        Thread.sleep(20);
                    } catch (InterruptedException e) {
                    }
                }
            }
        };
    t.start();
    }
}
