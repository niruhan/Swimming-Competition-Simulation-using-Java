/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package myswimmingcompetition;

/**
 *
 * @author niruhan
 */
public abstract class Person {
    public String name, sex;
    public int age;
}
