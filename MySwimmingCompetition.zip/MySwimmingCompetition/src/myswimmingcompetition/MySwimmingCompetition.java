package myswimmingcompetition;

import java.util.ArrayList;

public class MySwimmingCompetition {
    ArrayList<Swimmer> swimmersList = new ArrayList();
    int numberOfSwimmers = 0;
    public MySwimmingCompetition() {
    }
    
    public void addSwimmer(String nameInput, int styleIndex) {
        Swimmer newSwimmer = new Swimmer();
        newSwimmer.name = nameInput;
        if (styleIndex == 1) {
            newSwimmer.maxSpeed = 3;
        }
        else if (styleIndex == 2) {
            newSwimmer.maxSpeed = 4;
        }
        else if (styleIndex == 3) {
            newSwimmer.maxSpeed = 5;
        }
        swimmersList.add(newSwimmer);
    }
    
    public static void main(String[] args) {
        
    }
    
}